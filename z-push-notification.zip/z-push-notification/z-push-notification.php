<?php 
/* 
Plugin Name: Z Push Notification 
Description: Send push notification to mobile from WP 
Version: 1.0 
Author: Zaigo
License: GPLv2 or later */

define( 'WPLCG_PLUGIN', __FILE__ );
define( 'WPLCG_PLUGIN_BASENAME', plugin_basename( WPLCG_PLUGIN ) );
define( 'WPLCG_PLUGIN_NAME', trim( dirname( WPLCG_PLUGIN_BASENAME ), '/' ) );
define( 'WPLCG_PLUGIN_DIR', untrailingslashit( dirname( WPLCG_PLUGIN ) ) );
define( 'WPLCG_PLUGIN_URL',
	untrailingslashit( plugins_url( '', WPLCG_PLUGIN ) ) );
	
	
add_action( 'rest_api_init', 'getDeviceData');
add_action( 'rest_api_init', 'triggerPushNotification');
add_action( 'rest_api_init', 'triggerPushAllNotification');
add_action( 'rest_api_init', 'displayFcmMsg');

//device token and device id storing api
function getDeviceData(){
    register_rest_route( 'zpushnotification/api/v1', '/devicedata/(?P<deviceToken>.+)/(?P<deviceID>.+)', array(
        'methods' => 'GET',
        'callback' => 'getDeviceDataCallback',
    ));
}
 
 //device token and device id storing api
function triggerPushNotification(){
    register_rest_route( 'zpushnotification/api/v1', '/sendnotification/(?P<deviceToken>.+)', array(
        'methods' => 'GET',
        'callback' => 'triggerPushNotificationCallback',
    ));	
}

//send all notification api
function triggerPushAllNotification(){
    register_rest_route( 'zpushnotification/api/v1', '/sendallnotification/', array(
        'methods' => 'GET',
        'callback' => 'triggerPushAllNotificationCallback',
    ));	
}

//send all fcm message to app
function displayFcmMsg(){
    register_rest_route( 'zpushnotification/api/v1', '/sendallfcmmsg/', array(
        'methods' => 'GET',
        'callback' => 'triggerAllFcmmsgCallback',
    ));	
}

// store the  device token and device id
function getDeviceDataCallback($data){
	global $wpdb,$wp_query;   
	$deviceToken = $data['deviceToken']; 
	$deviceID = $data['deviceID']; 
	$current_date = date("Y-m-d h:i:s");
	
	if($deviceToken && $deviceID ){
		$table_name = $wpdb->prefix . 'fcm_details';		
		$result = $wpdb->get_results("SELECT * FROM ".$table_name." WHERE deviceid = '".$deviceID."'"); 
		if($wpdb->num_rows > 0 ){
		   $wpdb->query($wpdb->prepare("UPDATE $table_name 
                SET devicetoken = %s , updated_date = %s
             WHERE deviceid = %s",$deviceToken,$current_date,$deviceID)
           );
		}else{				
			$wpdb->insert($table_name, array(
				'deviceid' => $deviceID,
				'devicetoken' => $deviceToken,
				'created_date' => $current_date
			));
			
		}
		$msg = array("message"=>'Success !',"status" => '200');
		$msgs = json_encode($msg);
		$msgs = json_decode($msgs);
		return $msgs;
	}else{
	    $msg = array("message"=>'Failure !',"status" => '400');
		$msgs = json_encode($msg);
		$msgs = json_decode($msgs);
		return $msgs;	
		
	}
		
}

function triggerPushNotificationCallback($data){
	$deviceToken = $data['deviceToken']; 
	 
	//Add FCM Server Key Here
	$serverToken = "AAAASgVfSZk:APA91bGfM9IOWWYlfvNdvGfjBvhUqSYPGYMI8SZsv_WGlrXbphswCn2LLKw60bbfxbPfbbJH38N496PMCI2wh2alrHoY9_N0zFMPtw-MaQ_udxBNP2BBPSu-rC51yAw71fVFFMetWueN";
	
	//FCM API end-point
	$url = 'https://fcm.googleapis.com/fcm/send';
	$headers = array(
		'Content-Type:application/json',
		'Authorization:key='.$serverToken
	);

	$requestData = ["to" => $deviceToken, "notification" => ["title" => "Test Notification from Z Push Notification Plugin", "body" => "ZZZZZZZZZZ Notification","channelId" => 'easyapproach']];
	$formattedRequestData = json_encode($requestData);

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $formattedRequestData);
	$result = curl_exec($ch);
	if ($result === FALSE) {
		die('Oops! FCM Send Error: ' . curl_error($ch));
	}else{
		echo "Success !";
	}
	curl_close($ch);
	
}

function triggerPushAllNotificationCallback(){
	global $wpdb,$wp_query;   
	$deviceToken = array();
	$fcm_id = array();
	$table_name = $wpdb->prefix . 'fcm_details';		
	$result = $wpdb->get_results("SELECT * FROM ".$table_name.""); 
	if($wpdb->num_rows > 0 ){
		foreach ( $result as $row ){
			if($row->devicetoken){				
				$deviceToken[] = ($row->devicetoken)?$row->devicetoken:'';
			}
			if($row->id){
				$fcm_id[] = ($row->id)?$row->id:'';
			}	
		}
	}
	
	$msg_table_name = $wpdb->prefix . 'fcm_msg_details';
	if( count($fcm_id) > 0){
		$fcm_id_new = implode(',',$fcm_id);
		$current_date = date("Y-m-d h:i:s");
		$wpdb->insert($msg_table_name, array(
					'message_title' => "Test Notification from Z Push Notification Plugin",
					'message_description' => "ZZZZZZZZZZ Notification",
					'fcm_id' => $fcm_id_new,
					'created_date' => $current_date
		));
	}
	$deviceToken = "eXP9FlAZQtWdxVhj7cjkyS:APA91bH8mTqo12roIBO3QpWN8jHtoH5WefDJTJxGLqXa26Pxn3c1aQKKg3fJuV2nKnlGmEu6g3d51vJQZH_UjcKJZChYKeq6QyUWazZBd_D0mxroBq2ZfmJ7-nTCY5uyPjtA-YeCsQyo";
	$serverToken = "AAAASgVfSZk:APA91bGfM9IOWWYlfvNdvGfjBvhUqSYPGYMI8SZsv_WGlrXbphswCn2LLKw60bbfxbPfbbJH38N496PMCI2wh2alrHoY9_N0zFMPtw-MaQ_udxBNP2BBPSu-rC51yAw71fVFFMetWueN";
	
	//FCM API end-point
	$url = 'https://fcm.googleapis.com/fcm/send';
	$headers = array(
		'Content-Type:application/json',
		'Authorization:key='.$serverToken
	);
	
	/*$requestData = ["to" =>$deviceToken, "notification" => ["title" => "Test Notification", "body" => "ZZZZZZZZZZ Notification","channelId" => 'easyapproach',"isScheduled" => "true",
    "scheduledTime"=>"2021-10-21 14:28:00"]];,"isScheduled" => "true",
    "scheduledTime"=>"2021-10-21 14:28:00"*/
	$requestData = ["to" =>$deviceToken, "notification" => ["title" => "Test Notification", "body" => "ZZZZZZZZZZ Notification","channelId" => 'easyapproach'],
	"data" => ["click_action" => 'http://94.177.203.98/customwpplugin', "sound" => 'default',"status" => 'done',"screen"=>'screenA','route' => 'red']];
	//$requestData = ["registration_ids" =>$deviceToken, "notification" => ["title" => "Test Notification from Z Push Notification Plugin", "body" => "ZZZZZZZZZZ Notification","channelId" => 'easyapproach']];
	
	$formattedRequestData = json_encode($requestData);

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $formattedRequestData);
	$result = curl_exec($ch);	
	if ($result === FALSE) {
		die('Oops! FCM Send Error: ' . curl_error($ch));
	}else{
		echo "Success !";
	}
	curl_close($ch);
}
function triggerAllFcmmsgCallback(){
	global $wpdb,$wp_query;   
	$fcm_details = array();
	$table_name = $wpdb->prefix . 'fcm_msg_details';		
	$result = $wpdb->get_results("SELECT * FROM ".$table_name." order by id Desc"); 
	$j = 0;
	if($wpdb->num_rows > 0 ){
		foreach ( $result as $row ){
			if($row->id){
				$fcm_details[$j]['id'] = ($row->id)?$row->id:'';
				$fcm_details[$j]['message_title'] = ($row->message_title)?ucfirst($row->message_title):'';
				$fcm_details[$j]['message_description'] = ($row->message_description)?$row->message_description:'';
				$article_link = ($row->article_link) ? $row->article_link : '';
				 $fcm_details[$j]['click_action'] = $article_link;
				$j++;
			}	
		}
		return $fcm_details;
	}else{
		//$fcm_details[]['msg'] = "Not Found";
		//$fcm_details[]['status'] = "400";
		return $fcm_details; 
	}
	
}
/*
 * Creating fcm_details table --Start
 */
function fcmActivatedetails() {
	global $wpdb;
	global $db_version;
	$table_name = $wpdb->prefix . 'fcm_msg_details';
	$charset_collate = $wpdb->get_charset_collate();
	$sqlnew = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		message_title varchar(256) NULL,
		message_description text NULL,
		fcm_id text NULL,
		article_link varchar(256) NULL,
		scheduledate datetime DEFAULT NULL,
		created_date datetime DEFAULT NULL,
		updated_date datetime DEFAULT NULL,
		schedule_flag tinyint DEFAULT NULL,
		PRIMARY KEY  (id)
	) $charset_collate;";
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sqlnew );		
	add_option( 'db_version', $db_version );
}
register_activation_hook( __FILE__, 'fcmActivatedetails' );
/*
 * Creating fcm_details table --Start
 */
function fcmActivate() {
	global $wpdb;
	global $db_version;
	$table_name = $wpdb->prefix . 'fcm_details';
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		deviceid text NULL,
		devicetoken text NULL,
		created_date datetime DEFAULT NULL,
		updated_date datetime DEFAULT NULL,
		PRIMARY KEY  (id)

	) $charset_collate;";	
	dbDelta( $sql );
	add_option( 'db_version', $db_version );
}
register_activation_hook( __FILE__, 'fcmActivate' );

/*
 * Adding Admin dashboard menus and their pages
 */	
function custom_menu() { 

   add_menu_page( 
      'WV Metro News', 
      'WV Metro News', 
      'manage_options', 
      'wv_metro_news', 
      'wv_metro_news_form', 
      'dashicons-media-spreadsheet' 
     );
    add_submenu_page( 'wv_metro_news', 'Push Notification Message', 'Push Notification Message','manage_options', 'wv_metro_message','wv_metro_message_display');
}	
add_action('admin_menu', 'custom_menu');

require_once WPLCG_PLUGIN_DIR . '/z-push-function.php';

add_action( 'admin_footer', 'custom_fcm_callback', 20, 0 );
function custom_fcm_callback() {
	 wp_enqueue_script('fcm_custom_validation', WPLCG_PLUGIN_URL.'/js/jquery.validate.min.js?'.rand());
	 wp_enqueue_script('fcm_custom_script', WPLCG_PLUGIN_URL.'/js/custom_function.js?'.rand()); 	
     wp_enqueue_script('fcm_jquery_ui', WPLCG_PLUGIN_URL.'/js/jquery-ui.js?'.rand());	 
	 wp_enqueue_style('fcm_custom_style', WPLCG_PLUGIN_URL.'/css/style.css?'.rand()); 
	 wp_enqueue_style('fcm_jquery_ui', WPLCG_PLUGIN_URL.'/css/jquery-ui.css?'.rand());	 	 
}

add_filter( 'cron_schedules', 'isa_add_every_one_minutes' );
function isa_add_every_one_minutes( $schedules ) {
    $schedules['every_one_minutes'] = array(
            'interval'  => 60,
            'display'   => __( 'Every 1 Minutes', 'textdomain' )
    );
    return $schedules;
}

// Schedule an action if it's not already scheduled
if ( ! wp_next_scheduled( 'isa_add_every_one_minutes' ) ) {
    wp_schedule_event( time(), 'every_one_minutes', 'isa_add_every_one_minutes' );
}

// Hook into that action that'll fire every three minutes
add_action( 'isa_add_every_one_minutes', 'every_one_minutes_event_func' );
function every_one_minutes_event_func() {
    // do something
	//echo "mahesh";
	global $wpdb,$wp_query;   
	
	$fcm_details = array();
	$table_name = $wpdb->prefix . 'fcm_msg_details';		
	$result = $wpdb->get_results("SELECT * FROM ".$table_name." where schedule_flag=0"); 
	
	$deviceToken = array();
	$fcm_id = array();
	$fcm_table_name = $wpdb->prefix . 'fcm_details';		
	$results = $wpdb->get_results("SELECT * FROM ".$fcm_table_name.""); 
	if($wpdb->num_rows > 0 ){
		foreach ( $results as $row ){
			if($row->devicetoken){				
				$deviceToken[] = ($row->devicetoken)?$row->devicetoken:'';
			}
			if($row->id){
				$fcm_id[] = ($row->id)?$row->id:'';
			}	
		}
	}
	
	if($wpdb->num_rows > 0 ){
		foreach ( $result as $row ){
			if($row->id){
				$row_ids = $row->id;
				$message_title = ($row->message_title)?$row->message_title:'';
				$message_description = ($row->message_description)?$row->message_description:'';
			    //$message_description .=" Schedule Date: ".$message_description;
				$article_link = ($row->article_link)?$row->article_link:'N/A';
				if($row->scheduledate){
					//$scheduledate = $row->scheduledate;
					//$dates = date_create();
					
					$dates = $row->scheduledate;
					$datesnew = date_create($dates);
					$scheduledate = date_format($datesnew,"Y-m-d H:i"); 
					$current_date = date("Y-m-d H:i");
					
					if($scheduledate == $current_date){
						$serverToken = "AAAASgVfSZk:APA91bGfM9IOWWYlfvNdvGfjBvhUqSYPGYMI8SZsv_WGlrXbphswCn2LLKw60bbfxbPfbbJH38N496PMCI2wh2alrHoY9_N0zFMPtw-MaQ_udxBNP2BBPSu-rC51yAw71fVFFMetWueN";
						//FCM API end-point
						$url = 'https://fcm.googleapis.com/fcm/send';
						$headers = array(
							'Content-Type:application/json',
							'Authorization:key='.$serverToken
						);
						
						$requestData = ["registration_ids" =>$deviceToken, "notification" => ["title" => $message_title, "body" => $message_description,"channelId" => 'easyapproach'],"data" => ["click_action" => $article_link, "sound" => 'default',"status" => 'done',"screen"=>'screenA','route' => 'red']];
						$formattedRequestData = json_encode($requestData);
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, CURLOPT_POSTFIELDS, $formattedRequestData);
						$result = curl_exec($ch);	
						if ($result === FALSE) {
							die('Oops! FCM Send Error: ' . curl_error($ch));
							//echo "<p class='error_msg'>Oops! FCM Notification failed</p>";
						}else{
							 //echo "<p class='success_msg'>Success !</p>";
							 $wpdb->update($table_name, array('schedule_flag' => 1
), array('id' => $row_ids), array('%d'),array('%d'));

						}
						curl_close($ch);
					}
				}
			}	
		}		
	}
}
add_action( 'rest_api_init', 'triggerPushNotification');

// Test API Endpoint - [SITE_URL]/wp-json/zpushnotification/api/v1/sendnotification/[DEVICE_TOKEN]/[DEVICE_ID]
// Test API Endpoint Example - http://94.177.203.98/westbanknation/wp-json/zpushnotification/api/v1/sendnotification/[DEVICE_TOKEN]/[DEVICE_ID]
