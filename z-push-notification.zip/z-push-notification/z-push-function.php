<?php
function wv_metro_news_form(){
	
	?>	 
	<div class="fcm_form">
	 <h1>WV Metro News</h1>	 
	 <img src="<?php echo WPLCG_PLUGIN_URL.'/images/metro.png';?>" class="metrologo">
	 <form name='fcm_settings' class='fcm_settings_form'>
	   <div class="fcm_group_div">
	    <div class="fcm_group">
		   <label>Push Notification Title</label>
		   <div class="inputs">
		     <input type="text" id="fcm_title" name="fcm_title" value=''>
		   </div>
	   </div>
	   <div class="fcm_group">
		   <label>Push Notification Description</label>
		   <div class="inputs">
		    <textarea id="fcm_description" name="fcm_description"></textarea>
		   </div>
	   </div>
	   <div class="fcm_group">
		   <label>News & Article Link</label>
		   <div class="inputs">
		   <input type="text" id="click_action" name="click_action" value=''>
		   </div>
	   </div>
	    <div class="fcm_group">
		   <label>Schedule Date and Time</label>
		   <div class="inputs">
		   <input type="datetime-local" id="date" name="date" value=''>
		   </div>
	   </div>
	   <input type="hidden" id="ajax_url" name="ajax_url" value="<?php echo $ajax_url = admin_url( 'admin-ajax.php' ); ?>">	   
	   <input type="submit" id="submit" name="submit" value='Submit'>
	   <div class='message_display'></div>
	   </div>
	 </form>	 
	 </div>
<?php	
}
add_action( 'wp_ajax_fcm_settings', 'fcm_settings' );
function fcm_settings(){
	global $wpdb,$wp_query;	
	$fcm_title = sanitize_text_field($_REQUEST['fcm_title']);
	$fcm_description = sanitize_text_field($_REQUEST['fcm_description']);
	$click_action = sanitize_text_field($_REQUEST['click_action']);
	$scheduledate = sanitize_text_field($_REQUEST['schedule_date']);
	
	if($fcm_title && $fcm_description){	
		$deviceToken = array();
		$fcm_id = array();
		$table_name = $wpdb->prefix . 'fcm_details';		
		$result = $wpdb->get_results("SELECT * FROM ".$table_name.""); 
		if($wpdb->num_rows > 0 ){
			foreach ( $result as $row ){
				if($row->devicetoken){				
					$deviceToken[] = ($row->devicetoken)?$row->devicetoken:'';
				}
				if($row->id){
					$fcm_id[] = ($row->id)?$row->id:'';
				}	
			}
		}
		
		$msg_table_name = $wpdb->prefix . 'fcm_msg_details';
		if( count($fcm_id) > 0){
			$fcm_id_new = implode(',',$fcm_id);
			$timezone = wp_timezone_string();
			$times = $scheduledate.' '.$timezone;
			$scheduledate_new = gmdate('Y-m-d H:i:s', strtotime($times));
			//$scheduletimes = strtotime($scheduledate_new); 
			$wpdb->insert($msg_table_name, array(
						'message_title' => $fcm_title,
						'message_description' => $fcm_description,
						'article_link'=> $click_action,
						'fcm_id' => $fcm_id_new,
						'scheduledate' => $scheduledate_new,
						'created_date' => $current_date,
						'schedule_flag' => 0
			));
		}
		echo "<p class='success_msg'>Success !</p>";
	}else{
		echo "<p class='error_msg'>Please enter a title and description</p>";
	}
	exit;	
}
function wv_metro_message_display(){
	global $wpdb,$wp_query;
	?>
	<div class="fcm_message_details">
	 <h1>Push Notification List</h1>	
	 <table class="wp-list-table widefat  striped posts">
	  <thead>
	    <tr>
	     <th class="manage-column">S.No</th>
		 <th class="manage-column">Title</th>
		 <th class="manage-column">Description</th>
		 <th class="manage-column">Link</th>
		 <th class="manage-column">Schedule Date</th>
		 <th class="manage-column">Status</th>
	    </tr>
	  </thead>
	  <tbody id="the-list">
	 <?php
	 $fcm_details = array();
	 $table_name = $wpdb->prefix . 'fcm_msg_details';		
	 $result = $wpdb->get_results("SELECT * FROM ".$table_name.""); 
	 $j = 0;
	 if($wpdb->num_rows > 0 ){
		foreach ( $result as $row ){
			if($row->id){
				$fcm_details[$j]['id'] = ($row->id)?$row->id:'';
				$fcm_details[$j]['message_title'] = ($row->message_title)?$row->message_title:'';
				$fcm_details[$j]['message_description'] = ($row->message_description)?$row->message_description:'';
				$fcm_details[$j]['links'] = ($row->article_link)?$row->article_link:'N/A';
				$fcm_details[$j]['scheduledate'] = ($row->scheduledate)?$row->scheduledate:'';
				$j++;
			}	
		}		
	 }
	 if(count($fcm_details)>0){ 
	     $k = 1;
	     foreach ( $result as $row ){
	 ?>
		 <tr colspan="5">
          <td class="manage-column"><?php echo $k; ?></td>
		  <td class="manage-column"><?php echo $row->message_title; ?></td>
		  <td class="manage-column"><?php echo $row->message_description; ?></td>	
		  <td class="manage-column article_links"><a target="_blank" href="<?php echo $row->article_link; ?>"><?php echo $row->article_link; ?></a></td>	
		  <?php
		  $date_str = '';
		  if($row->scheduledate){
			//$dates =date_create($row->scheduledate);
			$timezone = wp_timezone_string();
			$time = strtotime($row->scheduledate.' '.$timezone);
			$date_str = date("Y-m-d H:i:s", $time);
		   // $dates = date_format($dates,"d-m-Y H:i:s"); 
		  }
		  $status_str = '';
		  if($row->schedule_flag == 1){
			  $status_str = 'Completed';
		  }else{
			 $status_str = 'Queued'; 
		  }
		  ?>
		  <td class="manage-column"><?php echo $date_str; ?></td>	
		  <td class="manage-column"><?php echo $status_str; ?></td>		  
         </tr>
	<?php	
	      $k++;
         }
		 
	 }else{ ?>
		<tr colspan="3">
          <td class="manage-column">No Data Found </td>    
        </tr>		
		 
	<?php	 
	 }
	 ?>
	 </tbody>
	 </table>
	</div>
  <?php	 
}