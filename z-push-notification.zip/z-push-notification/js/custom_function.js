jQuery(document).ready(function() {
  /*Learndash Group settings validation */
  jQuery(".fcm_settings_form").validate({    
    rules: {         
      fcm_title: {
        required: true,
      },
      fcm_description: {
        required: true,
      }
    },
    // Make sure the form is submitted to the destination defined   
    submitHandler: function(form) {		
      //form.submit();	  
	   var ajax_url = jQuery('.fcm_settings_form #ajax_url').val();
	   var fcm_title = jQuery('.fcm_settings_form #fcm_title').val();
	   var fcm_description = jQuery('.fcm_settings_form #fcm_description').val();
	   var click_action = jQuery('.fcm_settings_form #click_action').val();
	   var schedule_date = jQuery('.fcm_settings_form #date').val();
	   var schedule_dates = schedule_date.replace("T", " ");
	   if(click_action ==''){
		   click_action = '';
	   }
	   if(fcm_title != '' && fcm_description != ''){
		   jQuery(".fcm_settings_form .message_display").html('');
			var ajaxData = {
			'action': 'fcm_settings',
			'fcm_title': fcm_title,
			'fcm_description': fcm_description,
			'click_action':click_action,
			'schedule_date':schedule_dates
			}		  
			jQuery.post(ajax_url, ajaxData, function(response){	
			
			  jQuery(".fcm_settings_form .message_display").css('display','block');	
			  jQuery(".fcm_settings_form .message_display").html(response);			  
			});	
		}		
		return false;
    }
  });
  
 
});
